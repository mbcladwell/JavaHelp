
General
-------

JHelpDev is a help authoring tool for the JavaHelp system.
Create your HTML content with another tool and use JHelpDev 
for creating TOC, INDEX and MAP files.

Running JHelpDev
----------------

-make sure a Java Virtual Machine is installed (minimum JRE 1.5)
-click on jhelpdev.jar or on jh.bat (with console)

Getting Started
---------------

Check out the "Getting Started" section in the helpsystem.

Contact
-------

The project homepage is:

http://jhelpdev.sourceforge.net

All information can be accessed from there, including 
bug reports and feature requests.

License
-------

JHelpDev is open source software. The 
GNU Lesser Public License applies. 
See the attached license file.