java -jar -classpath ".:jhelpdev.jar:lib/jhall.jar:lib/xmlenc.jar" jhelpdev.jar
